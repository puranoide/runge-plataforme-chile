<?php 
$servername = "localhost";
$username = "root";
$password = "";
$database = "rungeDatabasev2";
$conexion = mysqli_connect($servername,$username,$password,$database);

//header("location:../index");
/*
if($conexion){
    echo "conectado exitosamente a la base de datos";
}else{
    echo "no se conecto";
}*/
?>